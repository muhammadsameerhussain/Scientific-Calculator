import MainFuncs as m
def clear():
    m.p=""
    m.s.set(m.p)
