import MainFuncs as m

def click(n):
    m.p=m.p + str(n)
    m.s.set(m.p)
