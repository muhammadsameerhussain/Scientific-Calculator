from sine import sin
def cosec(x):
    if x==0:
        return "Math Error"
    else:
        return (1/(sin(x)))
