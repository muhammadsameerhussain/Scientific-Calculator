def cube(x):
    return x**3
