def cuberoot(x):
    return (x**(1/3))
