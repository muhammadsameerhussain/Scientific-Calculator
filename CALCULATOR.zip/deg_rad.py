import pi
def deg(x):
    return x*((pi.pi())/180)
