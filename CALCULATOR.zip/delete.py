import MainFuncs as m
def delete():
    m.p=m.p[:-1]
    m.s.set(m.p)

