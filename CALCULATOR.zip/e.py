def e():
    return 2.718281828
