import MainFuncs as m
from factorial import factorial
from sine import sin
from tan import tan
from cosine import cos
from sqroot import sqroot
from cuberoot import cuberoot
from absolute import absolute
from deg_rad import deg
from rad_deg import rad
from quadratic import quad
from logarithm import log,ln
from roots import root
from power import power
from sininv import asin
from cosinv import acos
from taninv import atan
from per import nPr
from roots import root
from power import power
from comb import nCr
from cosec import cosec
from cot import cot
from sec import sec
from sign import sign
from cube import cube
from square import sq
from inv import inv
def equals():
    sumup=str(eval(m.p))
    m.p=str(sumup) 
    m.s.set(m.p)
