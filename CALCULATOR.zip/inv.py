def inv(x):
    return (x**(-1))
