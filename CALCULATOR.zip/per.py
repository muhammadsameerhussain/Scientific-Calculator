from factorial import factorial
def nPr(n,r):
    b=factorial(n)/factorial(n-r)
    return b
