def pi():
    return 22/7
