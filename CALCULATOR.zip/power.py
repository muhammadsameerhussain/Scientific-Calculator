def power(x,y):
    return x**y
