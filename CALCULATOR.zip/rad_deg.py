
def rad(x):
    return x*(180/(22/7))
