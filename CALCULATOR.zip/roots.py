def root(x,y):
    return (x**(1/y))
