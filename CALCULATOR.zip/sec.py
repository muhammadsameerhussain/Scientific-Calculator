from cosine import cos
def sec(x):
    return (1/(cos(x)))
