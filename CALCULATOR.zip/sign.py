def sign(x):
    return x*(-1)
