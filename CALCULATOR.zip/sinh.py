def sinh(x):
    e=2.718281828
    return(((e**(x))-(e**(-x)))/(2))
