def sqroot(x):
    return (x**(1/2))
