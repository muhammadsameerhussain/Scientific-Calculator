def sq(x):
    return x**2
