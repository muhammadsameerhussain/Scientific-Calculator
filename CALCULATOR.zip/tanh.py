import sinh
import cosh
def tanh(x):
    return((sinh.sinh(x))/(cosh.cosh(x)))
